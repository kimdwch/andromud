package basement.lab.mudclient.bean;

public class Alias {
	public String name;
	public String body;

	public Alias(String n, String b) {
		name = n;
		body = b;
	}
}
